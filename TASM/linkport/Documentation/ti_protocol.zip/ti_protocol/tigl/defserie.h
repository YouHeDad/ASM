/* D�claration des constantes */

#define COM1 	0x3F8
#define COM2 	0x2F8
#define COM3 	0x3E8
#define COM4 	0x2E8
#define S1200	1200
#define S2400	2400
#define S4800	4800
#define S9600	9600
#define S19200  19200
#define TXBUF	0
#define RXBUF	0
#define DIVLSB	0
#define DIVMSB	1
#define LCR	3
#define MCR	4
#define LSR	5
#define MSR	6
#define IER	1

/* D�clarations des prototypes de fonctions */

/* Envoie un caract�re sur la liaison s�rie */
  void 		 sendbyte    (unsigned char c);
/* Attend r�ception d'un caract�re sur la liaison s�rie. Si aucun
caract�re n'est re�u ds les MAXTIME secondes, renvoie -1 */
  int		 getbyte     (void);
/* Initialise le port s�rie choisi */
  void 		 setcom      (int com_adr, int speed);
/* Renvoie 1 si le buffer de r�ception contient un ou plusieurs caract�res */
  int 		 rxd_full    (void);
/* Prend un caract�re au vol sur la liaison s�rie */
  unsigned char  rxd_read    (void);
/* Initialise la variable com_adr */
 void		 setport     (int com_adr, int port);