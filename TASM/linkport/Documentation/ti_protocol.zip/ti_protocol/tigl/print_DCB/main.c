/*  tilp - link program for TI calculators
 *  Copyright (C) 1999-2001  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/* "Home-made serial" link & "Black TIGraphLink" link unit */

#include <stdio.h>
#include <windows.h>

#define DCB_FILE_BIN "COMx.DCB"
#define DCB_FILE_TXT "COMx.TXT"

int main(int argc, char **argv)
{
	DCB dcb;
	BOOL fSuccess;
	char *comPort;
	FILE *f;
	HANDLE hCom;

	if(argc < 2)
	{
		fprintf(stdout, "Usage: print_dcb COMx\n");
		exit(0);
	}
	comPort = argv[1];
	fprintf(stdout, "COM port to use: <%s>\n", comPort);

	// Open COM port
	hCom = CreateFile(comPort, GENERIC_READ | GENERIC_WRITE, 0, 
		NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hCom == INVALID_HANDLE_VALUE)
	{
		fprintf(stderr, "CreateFile error\n");
		return -1;
	}

	// Retrieve config structure
	fSuccess = GetCommState(hCom, &dcb);
	if(!fSuccess)
	{
		fprintf(stderr, "GetCommState error\n");
		return -1;
	}

	// Write DCB informations in file (binary)
	f = fopen(DCB_FILE_BIN, "wb");
	if(f == NULL)
	{
		fprintf(stderr, "Unable to create this file: %s\n", DCB_FILE_BIN);
		exit(-1);
	}
	fwrite(&dcb, sizeof(DCB), 1, f);
	fprintf(stdout, "DCB structure written in %s\n", DCB_FILE_BIN);
	fclose(f);

	// Write DCB infos in file (text)
	f = fopen(DCB_FILE_TXT, "wt");
	if(f == NULL)
	{
		fprintf(stderr, "Unable to create this file: %s\n", DCB_FILE_TXT);
		exit(-1);
	}
	fprintf(f, "dcb.BaudRate = %i\n", dcb.BaudRate);
	fprintf(f, "dcb.fBinary = %i\n", dcb.fBinary);
	fprintf(f, "dcb.fParity = %i\n", dcb.fParity);
	fprintf(f, "dcb.fOutxCtsFlow = %i\n", dcb.fOutxCtsFlow);
	fprintf(f, "dcb.fOutxDsrFlow = %i\n", dcb.fOutxDsrFlow);
	fprintf(f, "dcb.fDtrControl = %i\n", dcb.fDtrControl);
	fprintf(f, "dcb.fDsrSensitivity = %i\n", dcb.fDsrSensitivity);
	fprintf(f, "dcb.fOutX = %i\n", dcb.fOutX);
	fprintf(f, "dcb.fInX = %i\n", dcb.fInX);
	fprintf(f, "dcb.fErrorChar = %i\n", dcb.fErrorChar);
	fprintf(f, "dcb.fNull = %i\n", dcb.fNull);
	fprintf(f, "dcb.fRtsControl = %i\n", dcb.fRtsControl);
	fprintf(f, "fAbortOnError = %i\n", dcb.fAbortOnError);
	fprintf(f, "dcb.ByteSize = %i\n", dcb.ByteSize);
	fprintf(f, "dcb.Parity = %i\n", dcb.Parity);
	fprintf(f, "dcb.StopBits = %i\n", dcb.StopBits);
	fprintf(stdout, "DCB structure written in %s\n", DCB_FILE_TXT);
	fclose(f);

	// Close COM port
	CloseHandle(hCom);

	fprintf(stdout, "%i %i %i\n", RTS_CONTROL_DISABLE, RTS_CONTROL_ENABLE, RTS_CONTROL_HANDSHAKE);

	return 0;
}	