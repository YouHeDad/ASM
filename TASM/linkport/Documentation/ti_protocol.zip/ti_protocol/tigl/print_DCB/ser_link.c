/*  tilp - link program for TI calculators
 *  Copyright (C) 1999-2001  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/* "Home-made serial" link & "Black TIGraphLink" link unit */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>

#include "timeout.h"
#include "ioports.h"
#include "typedefs.h"
#include "export.h"
#include "cabl_err.h"
#include "cabl_def.h"
#include "cabl_ext.h"

// Use Win32 functions for performing low level I/O accesses 
// instead of generic I/O functions
#ifdef __WIN32__
//# define USE_DCB
#endif

#if defined(__I386__) && defined(HAVE_ASM_IO_H) && defined(HAVE_SYS_PERM_H) || \
	defined (__WIN32__) || defined(__WIN16__) || defined(__ALPHA__)
static unsigned int com_addr;
#define com_out (com_addr+4)
#define com_in  (com_addr+6)
#endif

static int io_permitted = 0;
 
/*******************************************/
/* Multi-platform part (without using DCB) */
/*******************************************/

#if !defined(USE_DCB)

DLLEXPORT
int DLLEXPORT2 ser_init_port()
{
#if defined(__I386__) && defined(HAVE_ASM_IO_H) && defined(HAVE_SYS_PERM_H) || defined (__WIN32__) || defined(__WIN16__) || defined(__ALPHA__)
  com_addr = io_address;

  TRY(open_io(com_out, 1));
  io_permitted++;
  TRY(open_io(com_in, 1));
  io_permitted++;

  wr_io(com_out, 3);
  wr_io(com_out, 0);
  wr_io(com_out, 3);
#endif
  return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_open_port()
{
  return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_put(byte data)
{
#if defined(__I386__) && defined(HAVE_ASM_IO_H) && defined(HAVE_SYS_PERM_H) || defined (__WIN32__) || defined(__WIN16__) || defined(__ALPHA__)  
  int bit;
  int i;
  TIME clk;
  
  for(bit=0; bit<8; bit++)
    {
      if(data & 1)
	{
	  wr_io(com_out, 2);
	  START(clk);
	  do 
	    { 
	      if(ELAPSED(clk, time_out)) return ERR_SND_BIT_TIMEOUT;
	    }
	  while((rd_io(com_in) & 0x10));
	  wr_io(com_out, 3);
	  START(clk);
	  do 
	    { 
	      if(ELAPSED(clk, time_out)) return ERR_SND_BIT_TIMEOUT;
	    }
	  while((rd_io(com_in) & 0x10)==0x00);
	}
      else
	{
	  wr_io(com_out, 1);
	  START(clk);
          do 
	    { 
	      if(ELAPSED(clk, time_out)) return ERR_SND_BIT_TIMEOUT;
	    }
	  while(rd_io(com_in) & 0x20);
	  wr_io(com_out, 3);
	  START(clk);
          do 
	    { 
	      if(ELAPSED(clk, time_out)) return ERR_SND_BIT_TIMEOUT;
	    }
	  while((rd_io(com_in) & 0x20)==0x00);
        }
      data>>=1;
      for(i=0; i<delay; i++) rd_io(com_in);
    }
#endif
  return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_get(byte *d)
{
#if defined(__I386__) && defined(HAVE_ASM_IO_H) && defined(HAVE_SYS_PERM_H) || defined (__WIN32__) || defined(__WIN16__) || defined(__ALPHA__)  
	
  int bit;
  byte data=0;
  byte v;
  int i;
  TIME clk;

  for(bit=0; bit<8; bit++)
    {
      START(clk);
      while((v=rd_io(com_in) & 0x30)==0x30)
	{
	  if(ELAPSED(clk, time_out)) return ERR_RCV_BIT_TIMEOUT;
	}
      if(v==0x10)
	{
	  data=(data >> 1) | 0x80;
	  wr_io(com_out, 1);
	  while((rd_io(com_in) & 0x20)==0x00);
	  wr_io(com_out, 3);
	}
      else
	{
	  data=(data >> 1) & 0x7F;
	  wr_io(com_out, 2);
	  while((rd_io(com_in) & 0x10)==0x00);
	  wr_io(com_out, 3);
	}
      for(i=0; i<delay; i++) rd_io(com_in);
    }
  *d=data;
#endif
  return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_probe_port()
{
#if defined(__I386__) && defined(HAVE_ASM_IO_H) && defined(HAVE_SYS_PERM_H) || defined (__WIN32__) || defined(__WIN16__) || defined(__ALPHA__)  
	
  int i, j;
  int seq[]={ 0x00, 0x20, 0x10, 0x30 };

  for(i=3; i>=0; i--)
    {
      wr_io(com_out, 3);
      wr_io(com_out, i);
	  for(j=0; j<10; j++) rd_io(com_in);
	  //DISPLAY("%i %02X %02X %02X\n", i, rd_io(com_in), rd_io(com_in) & 0x30, seq[i]);
      if( (rd_io(com_in) & 0x30) != seq[i])
	{
	  wr_io(com_out, 3);
	  return ERR_ROOT;
	}
    }
  wr_io(com_out, 3);
#else
  return ERR_ABORT;   
#endif
  
  return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_close_port()
{
#if defined(__I386__) && defined(HAVE_ASM_IO_H) && defined(HAVE_SYS_PERM_H) || defined (__WIN32__) || defined(__WIN16__) || defined(__ALPHA__)  
	
  if(io_permitted == 2)
    wr_io(com_out, 3);
#endif

  return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_term_port()
{
#if defined(__I386__) && defined(HAVE_ASM_IO_H) && defined(HAVE_SYS_PERM_H) || defined (__WIN32__) || defined(__WIN16__) || defined(__ALPHA__) 
	
  TRY(close_io(com_out, 1));
  io_permitted--;
  TRY(close_io(com_in, 1));
  io_permitted--;
#endif

  return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_check_port(int *status)
{
  *status = STATUS_NONE;
#if defined(__I386__) && defined(HAVE_ASM_IO_H) && defined(HAVE_SYS_PERM_H) || defined (__WIN32__) || defined(__WIN16__) || defined(__ALPHA__)  
  
  if(!( (rd_io(com_in) & 0x30) == 0x30 ))
    {
      *status = STATUS_BYTE_RCV;
    }
#endif

  return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_supported()
{
#if defined(__I386__) && defined(HAVE_ASM_IO_H) && defined(HAVE_SYS_PERM_H) || defined(__WIN32__) || defined(__WIN16__) || defined(__ALPHA__)
  return SUPPORT_ON | SUPPORT_IO;
#else
  return SUPPORT_OFF;
#endif
}


/**************************************************/
/* Win32 platform with DCB (Direct Control Block) */
/**************************************************/

// Remark: up to libticables library version 1.7.1, I use my own
// source code for initializing COM ports under Win32 platforms.
// When TiLP 4.10 has been released, it appeared that some people
// had problems with TiLP and BlackLink cables.
// Nethertheless, their link cable worked with Rusty Wagner's VTi.
// Then, I use now her routines: the code below comes from
// the Rusty's emulator.

#elif defined(USE_DCB)	

static HANDLE hCom=0;
static char comPort[MAXCHARS];

static int cl_getport()
{
    DWORD s;
    int b;

    GetCommModemStatus(hCom, &s);
    b = (s&MS_CTS_ON?1:0) | (s&MS_DSR_ON?2:0);
    return b;
}

static void cl_setport(int b)
{
    EscapeCommFunction(hCom, (b&2)?SETRTS:CLRRTS);
    EscapeCommFunction(hCom, (b&1)?SETDTR:CLRDTR);
}

DLLEXPORT
int DLLEXPORT2 ser_init_port()
{
	DCB dcb;
	BOOL fSuccess;
	COMMTIMEOUTS cto;
	char *name = comPort;
	int graphLink = 0;
	char str[128];

	strcpy(comPort, device);

	// Open COM port
	hCom = CreateFile(comPort, GENERIC_READ | GENERIC_WRITE, 0, 
		NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hCom == INVALID_HANDLE_VALUE)
	{
		fprintf(stderr, "CreateFile\n");
		print_last_error();
		return ERR_CREATE_FILE;
	}

	// Retrieve config structure
	fSuccess = GetCommState(hCom, &dcb);
	if(!fSuccess)
	{
		fprintf(stderr, "GetCommState\n");
		print_last_error();
		return ERR_GET_COMMSTATE;
	}

	dcb.BaudRate = CBR_9600;				// 9600 bauds
	dcb.fBinary = TRUE;						// Binary mode
	dcb.fParity = FALSE;					// Parity checking disabled
	dcb.fOutxCtsFlow = FALSE;				// No output flow control
	dcb.fOutxDsrFlow = FALSE;				// Idem
	dcb.fDtrControl = DTR_CONTROL_DISABLE;	// Provide power supply
	dcb.fDsrSensitivity = FALSE;			// ignore DSR status
	dcb.fOutX = FALSE;						// no XON/XOFF flow control
	dcb.fInX = FALSE;						// idem
	dcb.fErrorChar = FALSE;					// no replacement
	dcb.fNull = FALSE;						// don't discard null chars
	dcb.fRtsControl = RTS_CONTROL_ENABLE;	// Provide power supply
	dcb.fAbortOnError = FALSE;				// do not report errors

	dcb.ByteSize = 8;						// 8 bits
	dcb.Parity = NOPARITY;					// no parity checking
	dcb.StopBits = 0;

	// Config COM port
	fSuccess = SetCommState(hCom, &dcb);
	if(!fSuccess)
	{
		fprintf(stderr, "SetCommState\n");
		print_last_error();
		return ERR_SET_COMMSTATE;
	}

    fSuccess=GetCommTimeouts(hCom,&cto);
	if(!fSuccess)
	{
		fprintf(stderr, "GetCommTimeouts\n");
		print_last_error();
		return ERR_GET_COMMTIMEOUT;
	}
    
	cto.ReadIntervalTimeout = MAXDWORD;
    cto.ReadTotalTimeoutMultiplier = 0;
    cto.ReadTotalTimeoutConstant = 100 * time_out;	
    cto.WriteTotalTimeoutMultiplier = 0;
    cto.WriteTotalTimeoutConstant = 0;	// A value of 0 make non-blocking

    fSuccess=SetCommTimeouts(hCom,&cto);
	if(!fSuccess)
	{
		fprintf(stderr, "SetCommTimeouts\n");
		print_last_error();
		return ERR_SET_COMMTIMEOUT;
	}

	//DISPLAY("Serial port %s successfully reconfigured.\n", comPort);

	cl_setport(3);
	cl_setport(0);
	cl_setport(3);

	return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_open_port()
{
  return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_put(byte ch)
{
	int bit;
	int i;
	TIME clk;

	START(clk);
	for (i=0;i<8;i++)
	{
		if (ch&1)
			cl_setport(2);
        else
			cl_setport(1);
        while (cl_getport()!=0)
        {
			if(ELAPSED(clk, time_out)) return ERR_SND_BIT_TIMEOUT;
        }
        cl_setport(3);
        while (cl_getport()!=3)
        {
			if(ELAPSED(clk, time_out)) return ERR_SND_BIT_TIMEOUT;
        }
        ch>>=1;
	}

  return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_get(byte *ch)
{
	byte data=0;
	byte v;
	TIME clk;

	DWORD i,j,bit;
    unsigned char c;

    START(clk);
    for (i=0,bit=1,*ch=0;i<8;i++)
    {
        while ((j=cl_getport())==3)
        {
            if(ELAPSED(clk, time_out)) return ERR_RCV_BIT_TIMEOUT;
        }
        if (j==1)
        {
            *ch|=bit;
            cl_setport(1);
            j=2;
        }
        else
        {
            cl_setport(2);
            j=1;
        }
        while ((cl_getport()&j)==0)
        {
            if(ELAPSED(clk, time_out)) return ERR_RCV_BIT_TIMEOUT;
        }
        cl_setport(3);
        bit<<=1;
    }
  
  return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_probe_port()
{
  int i, j;
  int seq[]={ 0x00, 0x20, 0x10, 0x30 };

  for(i=3; i>=0; i--)
    {
      cl_setport(3);
      cl_setport(i);
	  for(j=0; j<10; j++) cl_getport(com_in);
	  //DISPLAY("%i %02X %02X %02X\n", i, rd_io(com_in), rd_io(com_in) & 0x30, seq[i]);
      if( (cl_getport() & 0x30) != seq[i])
	{
	  cl_setport(3);
	  return ERR_ROOT;
	}
    }
  cl_setport(3);
  return ERR_ABORT;   
  
  return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_close_port()
{
  if(io_permitted == 2)
    cl_setport(3);

  return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_term_port()
{
	if(hCom)
	{
		CloseHandle(hCom);
		hCom=0;
	}

	return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_check_port(int *status)
{

  return 0;
}

DLLEXPORT
int DLLEXPORT2 ser_supported()
{
  return SUPPORT_ON | SUPPORT_DCB;
}

#endif
