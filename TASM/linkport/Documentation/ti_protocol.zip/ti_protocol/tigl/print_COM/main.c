/*  tilp - link program for TI calculators
 *  Copyright (C) 1999-2001  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/* "Home-made serial" link & "Black TIGraphLink" link unit */

#include <stdio.h>
#include <windows.h>
#include <conio.h>

#define COM_FILE_TXT "COMx.TXT"

int main(int argc, char **argv)
{
	FILE *f;
	char *sAddr = "0x2f8";
	int addr;
	int i;

	if(argc < 2)
	{
		fprintf(stdout, "Usage: print_COM [COM address]\n");
		exit(0);
	}
	sAddr = argv[1];
	fprintf(stdout, "COM port to use: <%s>\n", sAddr);
	sscanf(sAddr, "0x%03x", &addr);

	// Write COM infos in file (text)
	f = fopen(COM_FILE_TXT, "wt");
	if(f == NULL)
	{
		fprintf(stderr, "Unable to create this file: %s\n", COM_FILE_TXT);
		exit(-1);
	}
	
	fprintf(stdout, "COM address: 0x%03x\n", addr);
	for(i=0; i<8; i++)
	{
		fprintf(stdout, "COM register @+%i: 0x%02x\n", i, _inp(addr+i));
		fprintf(f,      "COM register @+%i: 0x%02x\n", i, _inp(addr+i));
	}

	fprintf(stdout, "COM port parameters written in  %s\n", COM_FILE_TXT);
	fclose(f);

	return 0;
}	