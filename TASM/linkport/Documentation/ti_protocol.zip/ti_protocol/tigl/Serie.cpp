#include <stdio.h>
#include <dos.h>
#include <conio.h>
#include <time.h>
#include "DEFSERIE.H"

#define MAXTIME 5

int com_adr, com_speed;

void sendbyte (unsigned char c)
{ do {}
  while (!(inportb (com_adr+LSR) & 32));
  outportb (com_adr+TXBUF, c);

  return;
}
int getbyte (void)
{
  clock_t start = clock();
  int key;

  do
  {
    key=kbhit();
  }
  while ( !(inportb (com_adr+LSR) & 1) && !key);
  if (!key)
  { return inportb (com_adr+RXBUF); }
  else
  { return -1; }
}

void setcom (int pcom_adr, int speed)
{ long f=115200;
  int n_div, div_high, div_low;

  com_adr=pcom_adr;
  com_speed=speed;
  n_div = f / speed;
  div_low = n_div & 0x00FF;
  div_high = (n_div & 0xFF00)/256;
  outportb (com_adr+IER, 0);
  outportb (com_adr+LCR, 0x83);
  outportb (com_adr+DIVMSB, div_high);
  outportb (com_adr+DIVLSB, div_low);
  outportb (com_adr+LCR, 0x03);
}

int rxd_full (void)
{
  return (inportb (com_adr+LSR) & 1)==1;
}

unsigned char rxd_read (void)
{
  return inportb (com_adr+RXBUF);
}