#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "DEFSERIE.H"

int main (void)
{
  int data;
  int i;

  clrscr ();
  setcom (COM2, S9600);

  //data=inportb(COM2+MCR);
  //printf("MCR: %02X\n", data);

  for(i=0; i<=3; i++)
  {
    printf("MCR: (DTR en b0 et RTS en b1) %02X\n", i);
    outportb(COM2+MCR, i);
    printf("DSR: %i\n", (inportb(COM2+MSR) & 0x2) >> 1);
    printf("CTS: %i\n", inportb(COM2+MSR) & 0x1);
    printf("\n");
    getch();
  }

  /* Test if TI89 replys OK */
  sendbyte(0x08);
  sendbyte(0x68);
  sendbyte(0x00);
  sendbyte(0x00);


  for(i=0; i<4; i++)
  {
    data=getbyte();
    printf("data: %02X\n", data);
  }

  outportb(COM2+MCR, 0);
  return 0;
}