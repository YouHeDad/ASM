/*
  Mikael Magnusson 2000
*/

#include <windows.h>
#include <stdio.h>

typedef struct
{
    BYTE buf[256];
    int start;
    int end;
} LinkBuffer;

typedef struct
{
	LinkBuffer *buf;
	HANDLE hMap;
	int pos;
} Link;


void OpenLinks(Link buffers[], int nMax) {
	for(int i=0; i < nMax; i++) {
		char name[32];
		sprintf(name, "Virtual Link %d", i);
		HANDLE hMap = OpenFileMapping(FILE_MAP_READ, FALSE, name);
		if(hMap) {
			fprintf(stderr, "Opened %s\n", name);
			buffers[i].hMap = hMap;
			buffers[i].buf =(LinkBuffer*)MapViewOfFile(hMap, FILE_MAP_READ,0,0,sizeof(LinkBuffer));
		}
	}
}

void CloseLinks(Link buffers[], int nMax) {
	for(int i=0; i < nMax; i++) {
		if(buffers[i].hMap) {
			UnmapViewOfFile(buffers[i].buf);
			CloseHandle(buffers[i].hMap);
		}
	}
}

#define MAX_BUFFERS 8


int main(int argc, char *argv[]) {
	Link buffers[MAX_BUFFERS];

	BYTE buf[256];
	FILE *file;
	
	file = fopen("c:\\trace.dmp", "w");
	if(!file) {
		exit(-1);
	}

	memset(buffers, 0, sizeof(buffers));
	OpenLinks(buffers, MAX_BUFFERS);
	

	for(int i = 0; i < MAX_BUFFERS; i++) {
		if(buffers[i].buf) {
			buffers[i].pos = buffers[i].buf->end;
		}
	}

	int old = -1;
	for(;;) {
		Sleep(1);

		for(int i = 0; i < MAX_BUFFERS; i++) {
			if(!buffers[i].buf) {
				continue;
			}

			if(buffers[i].pos != buffers[i].buf->end) {
				break;
			}
		}

		if(i == MAX_BUFFERS) {
			continue;
		}

		int newPos = buffers[i].buf->end;
		int pos = buffers[i].pos;
		memcpy(buf, buffers[i].buf, 256);

		if(old != i) {
			old = i;
			fprintf(file, "\n%1d: ", i);
		}

		for(;pos != newPos; pos = (pos + 1)&255) {
			fprintf(file, "%02x ", buf[pos]);
		}

		buffers[i].pos = pos;
		fflush(file);
	}

	return 0;
}
