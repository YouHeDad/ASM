*******************************************
* Informations about these documentations *
*******************************************


If you experience some problems to read these docs under Windows then read it
under DOS (with edit for example) and save it again. Now, you can read under
Windows.


Note: the archive is made of several directories. There is a calculator
documentation by directory. In each directory, you will find a text 
documentation as well as some transfer samples. A file lists the samples and
give some comments about it.
These samples have been acquired thanks to my logic analyser: a Texas
Instruments DSK (DSP (Digital Signal Processing) Starter Kit) that I have 
programmed to make this work. Its characteristics are 25 MHz clock, 8Ko
of embedded memory and a direct link with the parallel port to download
samples.
Use TI equipment to hack TI protocol, it's fun !!!

There are 2 specific directories: one concerns the hardware protocol only and
the other ones concern the Grey TIGraphLink.

 
1) The TI92 documentation
-------------------------

A part of the documentation comes from the Pascal Bouron's documentation (which
is a grouping of other documentations: Per Finander, Ben Eater and George 
Nachman). I have completed this documentation thanks to my logic analyser.
The output files of the logic analyser are with the documentation (*.txt).


2) The TI92+ documentation
--------------------------

Although the TI92+ protocol is very similar to the TI92 protocol, I preferred
make two distinct documentations. This documentation is made starting at the
samples bringing about my logic analyser.


3) The TI89 documentation
-------------------------

The TI89 documentation gives only the protocol differences between the TI92+
and the TI89.


4) The TI82 documentation
-------------------------

A part of the documentation comes from the Pascal Bouron's documentation. I 
have greatly complete this doc thanks to my logic analyser.


5) The TI85 documentation
-------------------------

A part of the documentation comes from the Pascal Bouron's documentation. I
have greatly complete this doc thanks to my logic analyser.


6) The TI86 documentation
-------------------------

This documentation is made starting at the samples bringing about my logic 
analyser.

7) The TI83+ documentation
--------------------------

Doc written by Mikael Magnusson starting at the TI83 doc.


(c) Copyright 1999-2000 by Romain LIEVIN
Romain Lievin, developper of the GtkTiLink: <roms@lpg.ticalc.org>
GtkTiLink Official Homepage - http://lpg.ticalc.org/prj_gtktilink

If you find a mistake, a lack, or have more informations, please mail me...





